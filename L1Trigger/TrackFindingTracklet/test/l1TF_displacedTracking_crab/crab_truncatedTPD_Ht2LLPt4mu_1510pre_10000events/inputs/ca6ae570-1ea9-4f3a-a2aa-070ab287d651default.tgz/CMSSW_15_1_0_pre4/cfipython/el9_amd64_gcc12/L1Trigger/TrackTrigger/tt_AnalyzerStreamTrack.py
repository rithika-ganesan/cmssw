import FWCore.ParameterSet.Config as cms

def tt_AnalyzerStreamTrack(*args, **kwargs):
  mod = cms.EDAnalyzer('tt::AnalyzerStreamTrack',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
