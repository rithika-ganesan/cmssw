import FWCore.ParameterSet.Config as cms

def trklet_ProducerFakeDR(*args, **kwargs):
  mod = cms.EDProducer('trklet::ProducerFakeDR',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
