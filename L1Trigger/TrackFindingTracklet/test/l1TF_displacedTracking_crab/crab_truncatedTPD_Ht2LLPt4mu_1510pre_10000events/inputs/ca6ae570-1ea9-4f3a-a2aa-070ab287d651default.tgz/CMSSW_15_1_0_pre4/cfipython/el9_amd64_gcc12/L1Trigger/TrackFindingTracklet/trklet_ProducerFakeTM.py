import FWCore.ParameterSet.Config as cms

def trklet_ProducerFakeTM(*args, **kwargs):
  mod = cms.EDProducer('trklet::ProducerFakeTM',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
