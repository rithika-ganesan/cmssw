import FWCore.ParameterSet.Config as cms

def tt_ProducerAssociator(*args, **kwargs):
  mod = cms.ESProducer('tt::ProducerAssociator',
    appendToDataLabel = cms.string('')
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
