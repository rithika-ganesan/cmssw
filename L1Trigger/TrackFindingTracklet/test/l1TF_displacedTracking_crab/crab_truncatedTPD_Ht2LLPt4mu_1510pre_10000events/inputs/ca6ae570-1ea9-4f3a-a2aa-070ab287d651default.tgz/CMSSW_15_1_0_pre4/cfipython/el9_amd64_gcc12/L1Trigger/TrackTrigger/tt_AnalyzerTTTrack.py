import FWCore.ParameterSet.Config as cms

def tt_AnalyzerTTTrack(*args, **kwargs):
  mod = cms.EDAnalyzer('tt::AnalyzerTTTrack',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
