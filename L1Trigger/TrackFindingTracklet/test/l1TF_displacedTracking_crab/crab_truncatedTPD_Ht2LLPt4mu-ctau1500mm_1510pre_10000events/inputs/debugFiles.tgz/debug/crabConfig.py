from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.workArea = 'l1TF_displacedTracking_crab'
config.General.transferLogs = True
config.General.requestName = 'truncatedTPD_Ht2LLPt4mu-ctau1500mm_1510pre_10000events'
config.section_('JobType')
config.JobType.psetName = 'L1TrackNtupleMaker_cfg.py'
config.JobType.numCores = 4
config.JobType.maxMemoryMB = 4000
config.JobType.allowUndistributedCMSSW = True
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.publication = False
config.Data.inputDataset = '/HTo2LongLivedTo4mu_MH-125_MFF-12_CTau-1500mm_TuneCP5_14TeV-pythia8/Phase2Spring24DIGIRECOMiniAOD-PU200_Trk1GeV_140X_mcRun4_realistic_v4-v1/GEN-SIM-DIGI-RAW-MINIAOD'
config.Data.outLFNDirBase = '/store/user/rganesan'
config.Data.splitting = 'Automatic'
config.Data.totalUnits = 10000
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
