import FWCore.ParameterSet.Config as cms

def trklet_Demonstrator(*args, **kwargs):
  mod = cms.EDAnalyzer('trklet::Demonstrator',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
