from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'truncatedALL_dispSUSY_1510pre_10000events'
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'l1TF_displacedTracking_crab'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 4
config.JobType.psetName = 'L1TrackNtupleMaker_cfg.py'
config.JobType.maxMemoryMB = 4000
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/rganesan'
config.Data.publication = False
config.Data.inputDataset = '/DisplacedSUSY_stopToBottom_M-800_50mm_TuneCP5_14TeV-pythia8/Phase2Spring24DIGIRECOMiniAOD-PU200_AllTP_140X_mcRun4_realistic_v4-v1/GEN-SIM-DIGI-RAW-MINIAOD'
config.Data.splitting = 'Automatic'
config.Data.totalUnits = 10000
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
