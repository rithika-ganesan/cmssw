import FWCore.ParameterSet.Config as cms

def tt_AnalyzerMC(*args, **kwargs):
  mod = cms.EDAnalyzer('tt::AnalyzerMC',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
